function  [FF] = F_new(x,tnr,Lambda_new,pv,pq,S_B)
%pfF Calculate the residual of power flow Jacobian
%   Detailed explanation goes here

    V = x2V_pf(x, tnr);
    
    residual =  V .* conj(tnr.Ybus * V) - Lambda_new.*S_B;
    FF = [ 
      real(residual(pv));
      real(residual(pq));
      imag(residual(pq));
    ];
end

