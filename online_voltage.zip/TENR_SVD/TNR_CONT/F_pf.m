function [F,S_FB] = F_pf( x, l, tnr)
%pfF Calculate the residual of power flow Jacobian
%   Detailed explanation goes here

    [pv, pq]  = deal(tnr.pv, tnr.pq);

       V = x2V_pf(x, tnr);
                    
    residual =  V .* conj(tnr.Ybus * V)- l*tnr.dS;
    F = [ 
      real(residual(pv));
      real(residual(pq));
      imag(residual(pq));
    ];
S_FB=tnr.dS;
end

