%% Online Voltage Stability Algorithm.........
clc;
clearvars;

%% Initial..........................

bloc_powers=[5;7;9;10];                       % selected perturbed buses............
lambda_epsilon=1.7;                           % Perturbed amount 1.0 is normal ........
%% Input Data.................................

datain=ext2int(case14);           % Case study.......
step=0.3;                         % Newton step for size......
step_alpha=0.9;                   % Newton step for Newton Corrector.......

Lambda_new=1.0;                   % Lambda_max for Delta_S^n
%% Voltage collapse point for base case/pre contingency operating point.....................

[Tole,x,l,z,Iter,J,V_pre,tnr]=tnr_testeig(datain,step);          % Voltage Collapse for delta_S^0

%% Generating new operating condition  S^{n}.................

[nbus,~]=size(datain.bus);
Ldfactor=ones(nbus,1);
Ldfactor(bloc_powers,1)=lambda_epsilon;


datain.bus(:,3)=datain.bus(:,3).*Ldfactor;        %% Perturbing P_l at selected buses with epsilon ........
datain.bus(:,4)=datain.bus(:,4).*Ldfactor;        %% Perturbing Q_l at selected buses with epsilon ........

sol = runpf(datain);                              %% Running power flow for new state S^{n} .......
[tnr_new]=tnr_init(sol);

S_B=tnr_new.dS;                                   %% Power Injection...... 

[pv, pq, npv, npq]  = deal(tnr_new.pv, tnr_new.pq, tnr_new.npv, tnr_new.npq);       

%% Newton Corrector Algorithm.............
Tolee = 1;  
Iterr = 1;
counterr = 0;
tic;
while (Tolee > 1e-5)
%% Power balance EQu.....

[FF] = F_pf( x, Lambda_new, tnr_new );
[ V_post ] = x2V_pf(x,tnr_new);
%% Jacobain matrix........

[JF,~] = J_pf( x,tnr_new);
vec_F=[-real(S_B([pv;pq]));-imag(S_B(pq))];

u=zeros(size(z,1),1);
u(end,1)=1;

%%

[ dJ,dJdl] = dJdxl_pf(x,Lambda_new, u, z, tnr_new);

%% Steady state angle stability.....
    
Ext_J=[JF vec_F; dJdl];

P_S=z'*(JF*z) ;

d_M=[FF;P_S];

corr = - Ext_J \d_M; 

dx= corr(1:end-1);
dLambda_new=corr(end);

x=x+step_alpha*dx;
Lambda_new=Lambda_new+step_alpha*dLambda_new;
   
    LL_P(Iterr)=P_S;
    Iterr = Iterr + 1;
    Tolee=max(abs(d_M));  
    counterr = counterr + 1;
    if counterr ==150
        break;
    end    
end
toc;

Index=abs(LL_P./LL_P(1,1));

semilogy(Index)

Lambda_new  
Tolee

Iterr




