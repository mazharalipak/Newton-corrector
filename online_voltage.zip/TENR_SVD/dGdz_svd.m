function [ dGdz ] = dGdz_svd( J, z )
%dGdz_svd Derivative wrt z
%   Detailed explanation goes here
    
    dGdz = [];
end

