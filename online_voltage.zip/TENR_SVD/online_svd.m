%% Online Voltage Stability Algorithm.........
clc;
clearvars;

%% Initial..........................

bloc_powers=[5;7;9];           % selected perturbed buses............
lambda_epsilon=2;               % Perturbed amount 1.0 is normal ........
%% Input Data.................................

datain=ext2int(case14);           % Case study.......
step=0.3;                         % Newton step for size......
step_alpha=0.95;                   % Newton step for Newton Corrector.......

Lambda_new=1.0;                   % Lambda_max for Delta_S^n
z=[];
%% Voltage collapse point for base case/pre contingency operating point.....................

[Tolex,x,l,Iter,J,V_pre,tnr]=tnr_testsvd(datain,step);        % Voltage Collapse for delta_S^0
[ G, u, v] = G_svd(J, z);                                     % (U^0)' J^0 V^0

%% Generating new operating condition  S^{n}.................

[nbus,~]=size(datain.bus);
Ldfactor=ones(nbus,1);
Ldfactor(bloc_powers,1)=lambda_epsilon;


datain.bus(:,3)=datain.bus(:,3).*Ldfactor;       %% Perturbing P_l at selected buses with epsilon ........
datain.bus(:,4)=datain.bus(:,4).*Ldfactor;       %% Perturbing Q_l at selected buses with epsilon ........

datain.gen(:,2)=datain.gen(:,2)*1;
datain.gen(:,3)=datain.gen(:,3)*1;

sol = runpf(datain);                             %% Running power flow for new state S^{n} .......
[tnr_new]=tnr_init(sol);

S_B=tnr_new.dS;                                  %% Power Injection...... 

[pv, pq, npv, npq]  = deal(tnr_new.pv, tnr_new.pq, tnr_new.npv, tnr_new.npq);       

%% Newton Corrector Algorithm.............
Tolee = 1;  
Iterr = 1;
counterr = 0;
tic;
while (Tolee > 1e-5)
%% Power balance EQu.....

[FF] = F_pf( x, Lambda_new, tnr_new );
[ V_post ] = x2V_pf(x,tnr_new);
lam = conj(F2S_pf(v, tnr_new));

% P_S  = ((abs(V_post)-abs(V_pre))'*imag(lam));


%% Jacobain matrix........

[JF,~] = J_pf( x,tnr_new);
vec_F=[-real(S_B([pv;pq]));-imag(S_B(pq))];
% Lastrow=zeros(size(JF,1),1);
% Lastrow(nbus:end)=imag(lam(pq));


%%
[ dJ] = dJdxl_pf(x,Lambda_new, u, v, tnr_new);

%% Steady state angle stability.....
    
Ext_J=[JF vec_F; dJ];

P_S=u'*(JF*v) ;

d_M=[FF;P_S];

corr = - Ext_J \d_M; 

dx= corr(1:end-1);
dLambda_new=corr(end);

x=x+step_alpha*dx;
Lambda_new=Lambda_new+step_alpha*dLambda_new;
   
    LL_P(Iterr)=P_S;
    TT(Iterr)=Iterr;
    Iterr = Iterr + 1;
    Tolee=max(abs(d_M));  
    counterr = counterr + 1;
    if counterr ==150
        break;
    end    
end
toc;

Index=abs(LL_P./LL_P(1,1));

semilogy(Index(2:end),'--')
 xlim([-Inf Inf])
 ylim([-Inf Inf])

Lambda_new  
Tolee

Iterr




