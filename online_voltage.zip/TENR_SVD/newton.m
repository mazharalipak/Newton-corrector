%% Conventional Power Flow.........
clc;
clearvars;
maxIters =12;
%% Initial seed / germ for starting TENR Algorithm...........................
testcase = case118;
mpc = loadcase(testcase);
mpc = ext2int(mpc);
%%
tnr = tnr_init(mpc);
x = V2x_pf(tnr.V0, tnr);
l=2.187;
step=1;
%% Newtpn Iterations ................................

Tole = 1;  
Iter = 1;
counter = 0;

while (Tole > 1e-5)  
[nx] = length(x);

F = tnr.F(x, l, tnr);

[J,~] = tnr.J(x,tnr);

dv = -J \ F;
x=x+step*dv;
%% Checking Tolerance.......
 Iter = Iter + 1;
 Tole=max(abs(F));
 counter = counter + 1;
 if counter ==30
     break;
 end
end

 if Iter >maxIters % check for non-convergence
    disp('Newton did not converge'); 
 else
     disp ('Newton converged')
end
